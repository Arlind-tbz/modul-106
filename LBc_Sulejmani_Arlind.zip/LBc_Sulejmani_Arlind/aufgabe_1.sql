CREATE TABLE award (
award_id INT NOT NULL AUTO_INCREMENT,
title VARCHAR(255) NOT NULL,
prize_money INT NOT NULL,
PRIMARY KEY(award_id)
);

CREATE TABLE film_award (
film_id INT NOT NULL,
award_id INT NOT NULL,
year INT NOT NULL,
FOREIGN KEY (film_id) REFERENCES film(film_id),
FOREIGN KEY (award_id) REFERENCES award(award_id)
);

