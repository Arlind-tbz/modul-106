INSERT INTO ACTOR (first_name, last_name) VALUES
("HANS", "MUSTER")