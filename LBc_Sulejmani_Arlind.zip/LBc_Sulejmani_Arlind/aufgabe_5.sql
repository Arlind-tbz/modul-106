DELETE FROM film_actor WHERE fk_film_actor_actor = 184;
DELETE FROM actor WHERE actor_id = 184;