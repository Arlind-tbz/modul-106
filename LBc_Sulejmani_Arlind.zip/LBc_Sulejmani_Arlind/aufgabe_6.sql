SELECT c.first_name, c.last_name, a.address FROM customer c 
INNER JOIN address a ON c.customer_id = a.address_id
WHERE customer_id = 497;