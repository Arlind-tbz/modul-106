SELECT film.rating, COUNT(film.rating) AS Anzahl
FROM film
GROUP BY film.rating;