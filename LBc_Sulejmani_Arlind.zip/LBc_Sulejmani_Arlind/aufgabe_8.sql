SELECT COUNT(r.rental_id), c.first_name, c.last_name FROM customer c
INNER JOIN rental r ON r.rental_id = c.customer_id
GROUP BY r.rental_id
ORDER BY first_name ASC;